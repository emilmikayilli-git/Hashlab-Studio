# HashLab — Hash Generator & File Integrity Verifier

Offline, single-file HTML/CSS/JavaScript application. Open `index.html` in modern Chrome or Edge; no server or terminal required.

## Features
- File integrity baseline: select original files, compute SHA-256, export a JSON manifest, then re-select files and compare. Reports unchanged, changed, new and missing files.
- Import a previously saved manifest to compare in a later session.
- Text/file SHA-1 (legacy), SHA-256, SHA-384 and SHA-512 digest calculation and manual hash verification.
- HMAC SHA-1 (legacy), SHA-256, SHA-384, SHA-512.
- AES-256-GCM text encryption/decryption, with random 16-byte salt and 12-byte nonce, PBKDF2-SHA-256 (310,000 iterations), portable JSON output.

## Security notes
All operations are local; the page has a restrictive CSP and does not send network requests. Hashing is not encryption. SHA-1 is for legacy compatibility only. The baseline manifest must be stored securely; this tool cannot protect against tampering with both files and the manifest. File names (not directory paths) are used as identifiers; duplicate names are rejected. Files are read into memory (50 MiB/file limit). Web Crypto availability depends on browser and local-file support. No security audit is claimed. Do not use this demo as a replacement for audited cryptographic software.

## Manual integrity test
1. Create `example.txt` with `hello`, select it in Step 1, click **Baseline yarat**, download JSON.
2. Change `example.txt` to `hello!` and save.
3. Select it in Step 2 and click **Faylları müqayisə et**: expect **DƏYİŞİB**.
4. Restore `hello` and compare again: expect **DƏYİŞMƏYİB**.
5. Reload the page, import the saved JSON manifest, and compare again.


## UI update
HashLab Studio: simplified home, Hash Generator as the default tool, separate File Integrity, HMAC and AES tabs. No terminal needed: open `index.html` locally.
